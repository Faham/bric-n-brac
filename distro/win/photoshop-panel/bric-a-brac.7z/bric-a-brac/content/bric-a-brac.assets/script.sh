#!/bin/bash
"/Applications/Adobe Photoshop CS5.1/Plug-ins/Panels/bric-a-brac/content/bric-a-brac.assets/7za" x -y -o"/private/var/folders/+n/+nA91xxSFYKhshjuFE-qQE+++TQ/-Tmp-/TemporaryItems/1364962735649" "/Users/faham/development/bric-a-brac/temp/arc2.brac" > "/private/var/folders/+n/+nA91xxSFYKhshjuFE-qQE+++TQ/-Tmp-/TemporaryItems/info.txt"
echo Done > "/private/var/folders/+n/+nA91xxSFYKhshjuFE-qQE+++TQ/-Tmp-/TemporaryItems/bric-a-brac-script.sh.sem"
